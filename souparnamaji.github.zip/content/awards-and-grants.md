---
title: 'Awards & Grants'
type: landing_bio_sidebar

design:
  # Section spacing
  spacing: '0rem'

# Page sections
sections:
  - block: markdown
    content:
      text: |-
        ◾ **Best Teaching Assistant Award**  
          Institute of Economics & Econometrics, GSEM, University of Geneva - 2022
        
        ◾ **Grant for Rare Voices in Economics Conference**
          Swiss National Science Foundation - 2022
        
        ◾ **Scholarship for Beginning Doctoral Students in Economics Program**
          Swiss National Bank - 2019-2020
        
        ◾ **Certificate for highest CGPA in the Master of Arts in Economics program**
          Jadavpur University - 2017
        
        ◾ **Gold Medal for securing first position in the Bachelor of Arts in Economics**
          Jadavpur University - 2014
        
        ◾ **Merit Scholarship for College and University Students**
          Govt. of India - 2011-2014
---

