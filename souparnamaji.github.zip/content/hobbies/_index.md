---
title: 'Hobbies'
date: 2024-05-19
type: landing_bio_sidebar

design:
  # Section spacing
  spacing: '0rem'

# Page sections
sections:
  - block: collection
    id: hobbies
    content:
      text: I enjoy travel.  Here is a selection of my travels over the years.
      filters:
        folders:
          - hobbies
    design:
      view: article-grid
      fill_image: true
      columns: 3
---
