---
title: This is a travel blog post
summary: Placeholder Text
date: 2025-05-14

authors:
  - admin

tags:
  - Travel
---

This is all about Geneva.
