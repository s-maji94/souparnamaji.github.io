---
title: 'CV'
type: landing_bio_sidebar

design:
  # Section spacing
  spacing: '0rem'

# Page sections
sections:
  - block: markdown
    content:
      text: |-
        You can download my full CV [here](../uploads/CV_Souparna_Maji.pdf)

        ### Short CV
        ◾ **CURRENT EMPLOYMENT**  
        **Postdoctoral Researcher** – University of Geneva (Sept 2024 - present)  
        **Consultant** - World Trade Organization (April 2024 - present)

        ◾ **EDUCATION**  
        **PhD in Economics** – University of Geneva (2024)  
        **Swiss Program for Beginning Doctoral Students in Economics** - Study Center Gerzensee (2020)  
        **MA in Economics** - Jadavpur University (2017)  
        **BA in Economics** - Jadavpur University (2014)  
---
