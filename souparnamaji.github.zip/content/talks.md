---
title: 'Talks'
type: landing_bio_sidebar

design:
  # Section spacing
  spacing: '0rem'

# Page sections
sections:
  - block: markdown
    content:
      text: |-
        ### PAST
        ◾ **2023 – 2024**. NEU Development Consortium (Harvard University); RViE Conference (Geneva); SITES Conferences (Naples
        and Prato); ifo Workshop (Dresden); WEOC Session (Pavia); European Conference on Domestic Violence (Reykjavik).  
        ◾ **2021 – 2022**. Alumni Conference (Gerzensee); Pol. Econ. Cluster (HEC Lausanne); Internal Seminars (GSEM, Geneva).  
        ◾ **2016 – 2018**. 6th & 7th IGC Growth Conference (Kolkata); Food Security after NFSA (Birbhum); RBI Seminar (Kolkata).  
---