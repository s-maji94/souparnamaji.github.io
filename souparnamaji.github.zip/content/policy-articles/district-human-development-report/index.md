---
title: "District Human Development Report of Purba Medinipur District, West Bengal"
authors:
- admin
date: "2019-04-07T00:00:00Z"
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: "2017-01-01T00:00:00Z"

# Publication type.
# Accepts a single type but formatted as a YAML list (for Hugo requirements).
# Enter a publication type from the CSL standard.
publication_types: ["report"]

# Publication name and optional abbreviated publication name.
publication: ""
publication_short: ""

# Summary. An optional shortened abstract.
summary: (with V. Mukherjee, P. Saha); Internal Report for the Government of West Bengal, 2019.

featured: true

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  focal_point: ""
  preview_only: false
---
