---
title: "Food Security Makes Headway in Tripura, But Gaps Remain"
authors:
- admin
date: "2019-03-01T00:00:00Z"
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: "2017-01-01T00:00:00Z"

# Publication type.
# Accepts a single type but formatted as a YAML list (for Hugo requirements).
# Enter a publication type from the CSL standard.
publication_types: ["article"]

# Publication name and optional abbreviated publication name.
publication: "The Wire"
publication_short: ""

# Summary. An optional shortened abstract.
summary: The Wire, 2017.

featured: true

links:
- name: Link
  url: https://thewire.in/rights/food-security-makes-headway-in-tripura-but-gaps-remain

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'The PDS in Tripura is going through a transition. Credit: Jorge Silva/Reuters'
  focal_point: ""
  preview_only: false
---
Although the National Food Security Act has increased the effective food security coverage, a household survey has revealed exclusion errors and problems of linkages of ration cards with Aadhaar.
[Read More...](https://thewire.in/rights/food-security-makes-headway-in-tripura-but-gaps-remain)