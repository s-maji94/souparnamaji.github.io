---
title: "Unprecedented Job Losses in Unorganized Sector Post Demonetisation"
authors:
  - admin
  - Pritam Saha
date: "2017-11-08T00:00:00Z"
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: "2017-01-01T00:00:00Z"

# Publication type.
# Accepts a single type but formatted as a YAML list (for Hugo requirements).
# Enter a publication type from the CSL standard.
publication_types: ["article"]

# Publication name and optional abbreviated publication name.
publication: "The Wire"
publication_short: ""

# Summary. An optional shortened abstract.
summary: (with P. Saha); The Wire, 2017.

featured: true

links:
- name: Link
  url: https://thewire.in/economy/unprecedented-job-losses-wage-decline-unorganised-sector-post-demonetisation

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'People hold their old high denomination bank notes as they stand in a queue to deposit them inside a bank in Kanpur, India, November 10, 2016. Credit: Reuters/Adnan Abidi'
  focal_point: ""
  preview_only: false
---
A study in December 2016 reported 40% and 32% job losses in the age groups of 40-55 and 22-30 years respectively during the first 50 days of demonetisation.
[Read More...](https://thewire.in/economy/unprecedented-job-losses-wage-decline-unorganised-sector-post-demonetisation)