---
title: "PDS has improved in West Bengal, but it’s still not up to the mark"
authors:
- admin
date: "2016-09-16T00:00:00Z"
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: "2017-01-01T00:00:00Z"

# Publication type.
# Accepts a single type but formatted as a YAML list (for Hugo requirements).
# Enter a publication type from the CSL standard.
publication_types: ["article"]

# Publication name and optional abbreviated publication name.
publication: "The Indian Express"
publication_short: ""

# Summary. An optional shortened abstract.
summary: (with J. Drèze); The Indian Express, 2016.

featured: true

links:
- name: Link
  url: https://indianexpress.com/article/opinion/columns/mamata-banerjee-public-distribution-system-west-bengal-food-security-act-3033234/

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'When people are not clear about their entitlements, it is easy to cheat them. (Illustration: C R Sasikumar)'
  focal_point: ""
  preview_only: false
---

Recent media reports suggest that the public distribution system (PDS) in West Bengal is now “doing enormously well” — as one headline put it