---
title: "Project Assistant"
type: landing_bio_sidebar

params:
  # Place hero photo in /static/img, and reference here with img/
  HeroImg: "img/indian_institute_of_technology.jpeg"

design:
  # Section spacing
  spacing: '0rem'

# Page sections
sections:
  - block: markdown
    content:
      title: "Indian Institute of Technology, Delhi"
      text: |-
        Dates: October 2016 – December 2016  
        Project ‑ Impact of Demonetization on the Unorganized Economic Sector of the Indian Economy:
        - Created a novel dataset from newspaper articles and drafted a report on the effects on the unorganized sector.
---
